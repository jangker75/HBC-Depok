package com.hbc.depok.network

import com.hbc.depok.model.Data

/**
 * @author Filippo
 * @version 1.0.0
 * @since Sun, 08/04/2018 at 17:59.
 */
class ApiResponse {
    lateinit var data: List<Data>
}